"""
Notification models for managing SMS and WhatsApp notifications
"""
from extensions import db
from datetime import datetime
from enum import Enum


class NotificationType(Enum):
    ATTENDANCE_ALERT = 'attendance_alert'
    PAYMENT_CONFIRMATION = 'payment_confirmation'
    FEE_REMINDER = 'fee_reminder'
    SUBSCRIPTION_REMINDER = 'subscription_reminder'
    GENERAL_ANNOUNCEMENT = 'general_announcement'
    EXAM_REMINDER = 'exam_reminder'
    HOLIDAY_NOTICE = 'holiday_notice'


class NotificationMethod(Enum):
    SMS = 'sms'
    WHATSAPP = 'whatsapp'
    EMAIL = 'email'


class NotificationStatus(Enum):
    PENDING = 'pending'
    SENT = 'sent'
    DELIVERED = 'delivered'
    FAILED = 'failed'
    RETRY = 'retry'


class Notification(db.Model):
    """Notification model for tracking sent notifications"""
    __tablename__ = 'notifications'
    
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=True)
    
    # Notification details
    notification_type = db.Column(db.Enum(NotificationType), nullable=False)
    method = db.Column(db.Enum(NotificationMethod), nullable=False)
    recipient_phone = db.Column(db.String(15), nullable=False)
    recipient_name = db.Column(db.String(100), nullable=False)
    
    # Message content
    message = db.Column(db.Text, nullable=False)
    template_id = db.Column(db.Integer, db.ForeignKey('notification_templates.id'), nullable=True)
    
    # Status tracking
    status = db.Column(db.Enum(NotificationStatus), default=NotificationStatus.PENDING)
    sent_at = db.Column(db.DateTime, nullable=True)
    delivered_at = db.Column(db.DateTime, nullable=True)
    failed_at = db.Column(db.DateTime, nullable=True)
    
    # Provider response
    provider_message_id = db.Column(db.String(100), nullable=True)
    provider_response = db.Column(db.Text, nullable=True)
    error_message = db.Column(db.Text, nullable=True)
    
    # Retry tracking
    retry_count = db.Column(db.Integer, default=0)
    max_retries = db.Column(db.Integer, default=3)
    next_retry_at = db.Column(db.DateTime, nullable=True)
    
    # Related entity information
    entity_type = db.Column(db.String(50), nullable=True)  # 'attendance', 'payment', etc.
    entity_id = db.Column(db.Integer, nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    school = db.relationship('School', backref='notifications', lazy=True)
    student = db.relationship('Student', backref='notifications', lazy=True)
    template = db.relationship('NotificationTemplate', backref='notifications', lazy=True)
    
    def __repr__(self):
        return f'<Notification {self.notification_type.value} to {self.recipient_phone} - {self.status.value}>'
    
    def mark_sent(self, provider_message_id=None, provider_response=None):
        """Mark notification as sent"""
        self.status = NotificationStatus.SENT
        self.sent_at = datetime.utcnow()
        self.provider_message_id = provider_message_id
        self.provider_response = provider_response
    
    def mark_delivered(self):
        """Mark notification as delivered"""
        self.status = NotificationStatus.DELIVERED
        self.delivered_at = datetime.utcnow()
    
    def mark_failed(self, error_message=None):
        """Mark notification as failed"""
        self.status = NotificationStatus.FAILED
        self.failed_at = datetime.utcnow()
        self.error_message = error_message
        
        # Schedule retry if within retry limit
        if self.retry_count < self.max_retries:
            self.status = NotificationStatus.RETRY
            self.retry_count += 1
            # Schedule next retry (exponential backoff)
            retry_delay_minutes = 2 ** self.retry_count
            self.next_retry_at = datetime.utcnow() + datetime.timedelta(minutes=retry_delay_minutes)
    
    def to_dict(self):
        """Convert notification to dictionary"""
        return {
            'id': self.id,
            'school_id': self.school_id,
            'student_id': self.student_id,
            'notification_type': self.notification_type.value,
            'method': self.method.value,
            'recipient_phone': self.recipient_phone,
            'recipient_name': self.recipient_name,
            'message': self.message,
            'template_id': self.template_id,
            'status': self.status.value,
            'sent_at': self.sent_at.isoformat() if self.sent_at else None,
            'delivered_at': self.delivered_at.isoformat() if self.delivered_at else None,
            'failed_at': self.failed_at.isoformat() if self.failed_at else None,
            'provider_message_id': self.provider_message_id,
            'provider_response': self.provider_response,
            'error_message': self.error_message,
            'retry_count': self.retry_count,
            'max_retries': self.max_retries,
            'next_retry_at': self.next_retry_at.isoformat() if self.next_retry_at else None,
            'entity_type': self.entity_type,
            'entity_id': self.entity_id,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class NotificationTemplate(db.Model):
    """Notification template model for customizable message templates"""
    __tablename__ = 'notification_templates'
    
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    
    # Template details
    name = db.Column(db.String(100), nullable=False)
    notification_type = db.Column(db.Enum(NotificationType), nullable=False)
    method = db.Column(db.Enum(NotificationMethod), nullable=False)
    
    # Template content
    subject = db.Column(db.String(200), nullable=True)  # For email notifications
    message_template = db.Column(db.Text, nullable=False)
    
    # Template variables (JSON format)
    available_variables = db.Column(db.Text, nullable=True)  # JSON string of available placeholders
    
    # Status
    is_active = db.Column(db.Boolean, default=True)
    is_default = db.Column(db.Boolean, default=False)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    school = db.relationship('School', backref='notification_templates', lazy=True)
    
    # Unique constraint
    __table_args__ = (
        db.UniqueConstraint('school_id', 'name', name='unique_school_template_name'),
    )
    
    def __repr__(self):
        return f'<NotificationTemplate {self.name} - {self.notification_type.value}>'
    
    def render_message(self, **kwargs):
        """Render message template with provided variables"""
        message = self.message_template
        for key, value in kwargs.items():
            placeholder = f'{{{key}}}'
            message = message.replace(placeholder, str(value))
        return message
    
    def to_dict(self):
        """Convert notification template to dictionary"""
        return {
            'id': self.id,
            'school_id': self.school_id,
            'name': self.name,
            'notification_type': self.notification_type.value,
            'method': self.method.value,
            'subject': self.subject,
            'message_template': self.message_template,
            'available_variables': self.available_variables,
            'is_active': self.is_active,
            'is_default': self.is_default,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class NotificationSettings(db.Model):
    """Notification settings model for school-level configuration"""
    __tablename__ = 'notification_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False, unique=True)
    
    # SMS settings
    sms_enabled = db.Column(db.Boolean, default=False)
    sms_provider = db.Column(db.String(50), nullable=True)  # 'fast2sms', 'textlocal', etc.
    sms_api_key = db.Column(db.String(200), nullable=True)
    sms_sender_id = db.Column(db.String(20), nullable=True)
    
    # WhatsApp settings
    whatsapp_enabled = db.Column(db.Boolean, default=False)
    whatsapp_provider = db.Column(db.String(50), nullable=True)  # 'twilio', 'whatsapp_cloud', etc.
    whatsapp_api_key = db.Column(db.String(200), nullable=True)
    whatsapp_phone_number = db.Column(db.String(20), nullable=True)
    
    # Email settings
    email_enabled = db.Column(db.Boolean, default=False)
    email_provider = db.Column(db.String(50), nullable=True)  # 'smtp', 'sendgrid', etc.
    email_api_key = db.Column(db.String(200), nullable=True)
    email_from_address = db.Column(db.String(120), nullable=True)
    
    # Notification preferences
    attendance_notifications = db.Column(db.Boolean, default=True)
    payment_notifications = db.Column(db.Boolean, default=True)
    fee_reminder_notifications = db.Column(db.Boolean, default=True)
    general_notifications = db.Column(db.Boolean, default=True)
    
    # Auto-notification settings
    auto_attendance_alerts = db.Column(db.Boolean, default=True)
    auto_payment_confirmations = db.Column(db.Boolean, default=True)
    auto_fee_reminders = db.Column(db.Boolean, default=True)
    
    # Timing settings
    fee_reminder_days = db.Column(db.Integer, default=7)  # Days before due date
    daily_summary_time = db.Column(db.Time, nullable=True)  # Time for daily summaries
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    school = db.relationship('School', backref='notification_settings', uselist=False, lazy=True)
    
    def __repr__(self):
        return f'<NotificationSettings for {self.school.name if self.school else "Unknown School"}>'
    
    def to_dict(self):
        """Convert notification settings to dictionary"""
        return {
            'id': self.id,
            'school_id': self.school_id,
            'sms_enabled': self.sms_enabled,
            'sms_provider': self.sms_provider,
            'sms_sender_id': self.sms_sender_id,
            'whatsapp_enabled': self.whatsapp_enabled,
            'whatsapp_provider': self.whatsapp_provider,
            'whatsapp_phone_number': self.whatsapp_phone_number,
            'email_enabled': self.email_enabled,
            'email_provider': self.email_provider,
            'email_from_address': self.email_from_address,
            'attendance_notifications': self.attendance_notifications,
            'payment_notifications': self.payment_notifications,
            'fee_reminder_notifications': self.fee_reminder_notifications,
            'general_notifications': self.general_notifications,
            'auto_attendance_alerts': self.auto_attendance_alerts,
            'auto_payment_confirmations': self.auto_payment_confirmations,
            'auto_fee_reminders': self.auto_fee_reminders,
            'fee_reminder_days': self.fee_reminder_days,
            'daily_summary_time': self.daily_summary_time.isoformat() if self.daily_summary_time else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }