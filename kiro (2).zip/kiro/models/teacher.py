"""
Teacher model for managing teacher information and assignments
"""
from extensions import db
from datetime import datetime
from enum import Enum


class TeacherStatus(Enum):
    ACTIVE = 'active'
    INACTIVE = 'inactive'
    ON_LEAVE = 'on_leave'
    TERMINATED = 'terminated'


class Teacher(db.Model):
    """Teacher model for managing teacher information"""
    __tablename__ = 'teachers'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    
    # Professional information
    employee_id = db.Column(db.String(50), nullable=False)
    designation = db.Column(db.String(100), nullable=True)  # 'Principal', 'Vice Principal', 'Teacher', etc.
    department = db.Column(db.String(100), nullable=True)
    qualification = db.Column(db.String(200), nullable=True)
    experience_years = db.Column(db.Integer, default=0)
    
    # Personal information
    phone = db.Column(db.String(15), nullable=False)
    emergency_contact = db.Column(db.String(15), nullable=True)
    address = db.Column(db.Text, nullable=True)
    date_of_birth = db.Column(db.Date, nullable=True)
    date_of_joining = db.Column(db.Date, nullable=False)
    
    # Employment details
    salary = db.Column(db.Numeric(10, 2), nullable=True)
    status = db.Column(db.Enum(TeacherStatus), default=TeacherStatus.ACTIVE)
    
    # Additional information
    bio = db.Column(db.Text, nullable=True)
    photo_url = db.Column(db.String(255), nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref='teacher_profile', lazy=True)
    school = db.relationship('School', backref='teachers', lazy=True)
    
    # Unique constraint
    __table_args__ = (
        db.UniqueConstraint('school_id', 'employee_id', name='unique_school_employee_id'),
    )
    
    def __repr__(self):
        return f'<Teacher {self.user.name if self.user else "Unknown"} ({self.employee_id})>'
    
    def get_assigned_classes(self):
        """Get classes assigned to this teacher"""
        return [assignment.class_info for assignment in self.class_assignments if assignment.is_active]
    
    def get_assigned_subjects(self):
        """Get subjects assigned to this teacher"""
        return [assignment.subject for assignment in self.subject_assignments if assignment.is_active]
    
    def to_dict(self):
        """Convert teacher to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'school_id': self.school_id,
            'employee_id': self.employee_id,
            'designation': self.designation,
            'department': self.department,
            'qualification': self.qualification,
            'experience_years': self.experience_years,
            'phone': self.phone,
            'emergency_contact': self.emergency_contact,
            'address': self.address,
            'date_of_birth': self.date_of_birth.isoformat() if self.date_of_birth else None,
            'date_of_joining': self.date_of_joining.isoformat() if self.date_of_joining else None,
            'salary': float(self.salary) if self.salary else None,
            'status': self.status.value,
            'bio': self.bio,
            'photo_url': self.photo_url,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class TeacherClassAssignment(db.Model):
    """Teacher class assignment model"""
    __tablename__ = 'teacher_class_assignments'
    
    id = db.Column(db.Integer, primary_key=True)
    teacher_id = db.Column(db.Integer, db.ForeignKey('teachers.id'), nullable=False)
    class_id = db.Column(db.Integer, db.ForeignKey('classes.id'), nullable=False)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    
    # Assignment details
    academic_year = db.Column(db.String(20), nullable=False)
    is_class_teacher = db.Column(db.Boolean, default=False)  # Is this teacher the class teacher?
    is_active = db.Column(db.Boolean, default=True)
    
    # Timestamps
    assigned_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    teacher = db.relationship('Teacher', backref='class_assignments', lazy=True)
    class_info = db.relationship('Class', backref='teacher_assignments', lazy=True)
    school = db.relationship('School', backref='teacher_class_assignments', lazy=True)
    
    def __repr__(self):
        return f'<TeacherClassAssignment {self.teacher.user.name if self.teacher and self.teacher.user else "Unknown"} -> {self.class_info.get_display_name() if self.class_info else "Unknown"}>'


class TeacherSubjectAssignment(db.Model):
    """Teacher subject assignment model"""
    __tablename__ = 'teacher_subject_assignments'
    
    id = db.Column(db.Integer, primary_key=True)
    teacher_id = db.Column(db.Integer, db.ForeignKey('teachers.id'), nullable=False)
    subject_id = db.Column(db.Integer, db.ForeignKey('subjects.id'), nullable=False)
    class_id = db.Column(db.Integer, db.ForeignKey('classes.id'), nullable=False)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    
    # Assignment details
    academic_year = db.Column(db.String(20), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    
    # Timestamps
    assigned_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    teacher = db.relationship('Teacher', backref='subject_assignments', lazy=True)
    subject = db.relationship('Subject', backref='teacher_assignments', lazy=True)
    class_info = db.relationship('Class', backref='subject_assignments', lazy=True)
    school = db.relationship('School', backref='teacher_subject_assignments', lazy=True)
    
    def __repr__(self):
        return f'<TeacherSubjectAssignment {self.teacher.user.name if self.teacher and self.teacher.user else "Unknown"} -> {self.subject.name if self.subject else "Unknown"}>'


class Assignment(db.Model):
    """Assignment model for teacher-created assignments"""
    __tablename__ = 'assignments'
    
    id = db.Column(db.Integer, primary_key=True)
    teacher_id = db.Column(db.Integer, db.ForeignKey('teachers.id'), nullable=False)
    class_id = db.Column(db.Integer, db.ForeignKey('classes.id'), nullable=False)
    subject_id = db.Column(db.Integer, db.ForeignKey('subjects.id'), nullable=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    
    # Assignment details
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    instructions = db.Column(db.Text, nullable=True)
    
    # File attachments
    file_path = db.Column(db.String(500), nullable=True)
    file_name = db.Column(db.String(255), nullable=True)
    file_size = db.Column(db.Integer, nullable=True)
    
    # Dates
    assigned_date = db.Column(db.Date, nullable=False)
    due_date = db.Column(db.Date, nullable=True)
    
    # Status
    is_active = db.Column(db.Boolean, default=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    teacher = db.relationship('Teacher', backref='assignments', lazy=True)
    class_info = db.relationship('Class', backref='assignments', lazy=True)
    subject = db.relationship('Subject', backref='assignments', lazy=True)
    school = db.relationship('School', backref='assignments', lazy=True)
    
    def __repr__(self):
        return f'<Assignment {self.title} by {self.teacher.user.name if self.teacher and self.teacher.user else "Unknown"}>'
    
    def to_dict(self):
        """Convert assignment to dictionary"""
        return {
            'id': self.id,
            'teacher_id': self.teacher_id,
            'class_id': self.class_id,
            'subject_id': self.subject_id,
            'school_id': self.school_id,
            'title': self.title,
            'description': self.description,
            'instructions': self.instructions,
            'file_path': self.file_path,
            'file_name': self.file_name,
            'file_size': self.file_size,
            'assigned_date': self.assigned_date.isoformat() if self.assigned_date else None,
            'due_date': self.due_date.isoformat() if self.due_date else None,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }