# Database and Storage Upgrade Design

## Overview

This design document outlines the comprehensive upgrade of the school management system's database and storage infrastructure. The upgrade will transition from SQLite to PostgreSQL, implement advanced caching, improve file storage, and add robust backup and monitoring systems.

## Architecture

### Current Architecture
- **Database**: SQLite (single-file database)
- **Storage**: Local file system
- **Caching**: None
- **Backup**: Manual
- **Monitoring**: Basic logging

### Target Architecture
- **Database**: PostgreSQL with connection pooling
- **Storage**: Hybrid (local + cloud storage)
- **Caching**: Redis for session and data caching
- **Backup**: Automated with cloud storage
- **Monitoring**: Comprehensive metrics and alerting

## Components and Interfaces

### 1. Database Layer Upgrade

#### PostgreSQL Configuration
```python
# Enhanced database configuration
SQLALCHEMY_DATABASE_URI = 'postgresql://user:password@localhost:5432/school_management'
SQLALCHEMY_ENGINE_OPTIONS = {
    'pool_size': 20,
    'max_overflow': 30,
    'pool_pre_ping': True,
    'pool_recycle': 3600,
    'echo': False  # Set to True for query logging in development
}
```

#### Migration System
- **Flask-Migrate**: Database schema versioning
- **Alembic**: Migration script generation and execution
- **Migration Validation**: Pre-migration checks and rollback support

#### Enhanced Models
```python
# Improved model with better indexing and constraints
class Student(db.Model):
    __tablename__ = 'students'
    
    # Indexes for performance
    __table_args__ = (
        db.Index('idx_student_school_admission', 'school_id', 'admission_no'),
        db.Index('idx_student_class_roll', 'class_id', 'roll_number'),
        db.Index('idx_student_name_search', 'name'),
        db.Index('idx_student_phone_search', 'phone'),
        db.UniqueConstraint('school_id', 'admission_no'),
        db.UniqueConstraint('school_id', 'roll_number')
    )
```

### 2. Caching Layer

#### Redis Integration
```python
# Redis configuration
REDIS_URL = 'redis://localhost:6379/0'
CACHE_TYPE = 'redis'
CACHE_REDIS_URL = REDIS_URL
CACHE_DEFAULT_TIMEOUT = 300
```

#### Caching Strategy
- **Session Caching**: User sessions and authentication tokens
- **Data Caching**: Frequently accessed school data, class lists, fee structures
- **Query Caching**: Complex report queries and dashboard statistics
- **File Metadata Caching**: File information and access permissions

### 3. File Storage System

#### Cloud Storage Integration
```python
# AWS S3 Configuration
AWS_ACCESS_KEY_ID = os.environ.get('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY')
AWS_S3_BUCKET = os.environ.get('AWS_S3_BUCKET')
AWS_S3_REGION = os.environ.get('AWS_S3_REGION', 'us-east-1')
```

#### File Management
- **Local Storage**: Temporary files and cache
- **Cloud Storage**: Permanent files (documents, photos, reports)
- **CDN Integration**: Fast file delivery through CloudFront
- **File Versioning**: Track file changes and maintain history

### 4. Backup and Recovery System

#### Automated Backup Strategy
```bash
# Daily backup script
#!/bin/bash
BACKUP_DIR="/backups/$(date +%Y-%m-%d)"
pg_dump school_management > "$BACKUP_DIR/database.sql"
tar -czf "$BACKUP_DIR/files.tar.gz" /app/uploads/
aws s3 sync "$BACKUP_DIR" s3://school-backups/$(date +%Y-%m-%d)/
```

#### Recovery Procedures
- **Point-in-time Recovery**: Restore to specific timestamp
- **Incremental Backups**: Efficient storage and faster recovery
- **Cross-region Replication**: Disaster recovery across geographic locations

### 5. Monitoring and Alerting

#### Database Monitoring
```python
# Database performance monitoring
from sqlalchemy import event
from sqlalchemy.engine import Engine
import time
import logging

@event.listens_for(Engine, "before_cursor_execute")
def receive_before_cursor_execute(conn, cursor, statement, parameters, context, executemany):
    context._query_start_time = time.time()

@event.listens_for(Engine, "after_cursor_execute")
def receive_after_cursor_execute(conn, cursor, statement, parameters, context, executemany):
    total = time.time() - context._query_start_time
    if total > 0.5:  # Log slow queries
        logging.warning(f"Slow query: {total:.2f}s - {statement[:100]}...")
```

#### Health Checks
- **Database Connectivity**: Monitor connection pool status
- **Query Performance**: Track slow queries and optimization opportunities
- **Storage Usage**: Monitor disk space and file storage quotas
- **Cache Performance**: Redis hit/miss ratios and memory usage

## Data Models

### Enhanced Student Model
```python
class Student(db.Model):
    __tablename__ = 'students'
    
    # Primary key with better performance
    id = db.Column(db.BigInteger, primary_key=True)
    
    # Soft delete support
    deleted_at = db.Column(db.DateTime, nullable=True)
    is_deleted = db.Column(db.Boolean, default=False, index=True)
    
    # Full-text search support
    search_vector = db.Column(TSVectorType('name', 'father_name', 'mother_name'))
    
    # Audit fields
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    updated_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    version = db.Column(db.Integer, default=1)
```

### File Management Model
```python
class FileUpload(db.Model):
    __tablename__ = 'file_uploads'
    
    id = db.Column(db.BigInteger, primary_key=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    
    # File information
    original_filename = db.Column(db.String(255), nullable=False)
    stored_filename = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(500), nullable=False)
    file_size = db.Column(db.BigInteger, nullable=False)
    mime_type = db.Column(db.String(100), nullable=False)
    
    # Storage location
    storage_type = db.Column(db.Enum('local', 'aws_s3', 'google_cloud'), default='local')
    storage_path = db.Column(db.String(500), nullable=False)
    
    # Access control
    is_public = db.Column(db.Boolean, default=False)
    access_permissions = db.Column(db.JSON)
    
    # Versioning
    version = db.Column(db.Integer, default=1)
    parent_file_id = db.Column(db.BigInteger, db.ForeignKey('file_uploads.id'))
    
    # Metadata
    uploaded_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
```

## Error Handling

### Database Error Handling
```python
from sqlalchemy.exc import IntegrityError, OperationalError
from flask import current_app

def handle_database_error(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except IntegrityError as e:
            db.session.rollback()
            current_app.logger.error(f"Database integrity error: {str(e)}")
            raise ValidationError("Data integrity constraint violated")
        except OperationalError as e:
            db.session.rollback()
            current_app.logger.error(f"Database operational error: {str(e)}")
            raise DatabaseError("Database operation failed")
    return wrapper
```

### File Storage Error Handling
```python
class FileStorageError(Exception):
    pass

def safe_file_upload(file, storage_type='local'):
    try:
        if storage_type == 'aws_s3':
            return upload_to_s3(file)
        else:
            return upload_to_local(file)
    except Exception as e:
        current_app.logger.error(f"File upload failed: {str(e)}")
        raise FileStorageError(f"Failed to upload file: {str(e)}")
```

## Testing Strategy

### Database Testing
- **Unit Tests**: Model validation and relationships
- **Integration Tests**: Database operations and transactions
- **Performance Tests**: Query performance and load testing
- **Migration Tests**: Schema migration validation

### Storage Testing
- **File Upload Tests**: Various file types and sizes
- **Cloud Storage Tests**: AWS S3 integration testing
- **Backup Tests**: Backup creation and restoration
- **Security Tests**: File access permissions and validation

### Cache Testing
- **Cache Performance**: Hit/miss ratios and response times
- **Cache Invalidation**: Proper cache clearing on data updates
- **Memory Usage**: Redis memory consumption monitoring

## Security Considerations

### Database Security
- **Connection Encryption**: SSL/TLS for database connections
- **Access Control**: Role-based database permissions
- **SQL Injection Prevention**: Parameterized queries and ORM usage
- **Audit Logging**: Track all database modifications

### File Security
- **Access Control**: Secure file access with proper authentication
- **Virus Scanning**: Automated malware detection for uploads
- **Encryption**: Encrypt sensitive files at rest and in transit
- **Secure URLs**: Time-limited signed URLs for file access

## Performance Optimization

### Database Optimization
```python
# Query optimization examples
def get_students_with_fees(school_id, class_id=None):
    query = db.session.query(Student, StudentFeeStatus)\
        .join(StudentFeeStatus, Student.id == StudentFeeStatus.student_id)\
        .filter(Student.school_id == school_id)\
        .filter(Student.is_deleted == False)
    
    if class_id:
        query = query.filter(Student.class_id == class_id)
    
    return query.options(
        joinedload(Student.class_info),
        joinedload(Student.school)
    ).all()
```

### Caching Strategy
```python
from flask_caching import Cache

cache = Cache()

@cache.memoize(timeout=300)
def get_school_statistics(school_id):
    return {
        'total_students': Student.query.filter_by(school_id=school_id, is_deleted=False).count(),
        'total_teachers': Teacher.query.filter_by(school_id=school_id).count(),
        'total_classes': Class.query.filter_by(school_id=school_id).count()
    }
```

## Deployment Strategy

### Migration Plan
1. **Phase 1**: Set up PostgreSQL and Redis infrastructure
2. **Phase 2**: Implement database migrations and data transfer
3. **Phase 3**: Deploy caching layer and optimize queries
4. **Phase 4**: Implement cloud storage and backup systems
5. **Phase 5**: Add monitoring and alerting systems

### Rollback Plan
- **Database Rollback**: Revert to SQLite backup if needed
- **File Rollback**: Restore files from backup storage
- **Configuration Rollback**: Switch back to previous configuration
- **Monitoring**: Continuous monitoring during migration process