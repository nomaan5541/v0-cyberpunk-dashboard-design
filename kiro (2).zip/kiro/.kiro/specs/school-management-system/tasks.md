# Implementation Plan

- [x] 1. Set up project structure and core configuration





  - Create Flask application structure with blueprints for different modules
  - Configure SQLAlchemy with PostgreSQL connection
  - Set up environment configuration for development and production
  - Create requirements.txt with all necessary dependencies
  - _Requirements: 8.1, 8.4_

- [-] 2. Implement database models and relationships


  - [ ] 2.1 Create User model with role-based authentication
    - Implement User class with bcrypt password hashing
    - Add role enumeration (super_admin, school_admin, teacher, student)
    - Create authentication helper methods
    - _Requirements: 8.1, 8.2_


  - [ ] 2.2 Create School model with subscription tracking
    - Implement School class with subscription date fields
    - Add subscription status enumeration and validation
    - Create subscription helper methods for days remaining calculation

    - _Requirements: 1.2, 1.3_

  - [ ] 2.3 Create academic models (Classes, Students, Subjects)
    - Implement Class model with school relationship
    - Create Student model with comprehensive profile fields
    - Add Subject model with class associations

    - Implement proper foreign key relationships
    - _Requirements: 2.2, 3.1, 3.3_

  - [ ] 2.4 Create operational models (Attendance, Payments, Fee Structure)
    - Implement Attendance model with date and status tracking
    - Create Payment and PaymentHistory models


    - Add FeeStructure model for class-wise fee configuration
    - Create ActivityLog model for audit trails
    - _Requirements: 4.3, 5.2, 5.3_

  - [ ] 2.5 Write database model unit tests
    - Create test fixtures for all models
    - Test model validation and constraints
    - Verify relationship integrity
    - _Requirements: 8.1, 8.5_

- [ ] 3. Implement authentication and authorization system
  - [ ] 3.1 Create authentication service
    - Implement login/logout functionality with JWT tokens
    - Create password hashing and validation utilities
    - Add session management with role-based claims
    - _Requirements: 8.1, 8.2_

  - [ ] 3.2 Implement role-based access control
    - Create permission decorators for route protection
    - Implement role validation middleware
    - Add school-level data isolation for multi-tenancy
    - _Requirements: 8.2, 8.3_

  - [ ] 3.3 Create shared login interface
    - Build login form with email and password fields
    - Implement role-based redirect logic after authentication
    - Add password reset functionality
    - _Requirements: 1.1, 8.1_

  - [ ] 3.4 Write authentication unit tests
    - Test password hashing and validation
    - Verify JWT token generation and validation
    - Test role-based access control
    - _Requirements: 8.1, 8.5_

- [ ] 4. Build super admin module
  - [ ] 4.1 Create school registration interface
    - Build registration form with school name, email, phone, password fields
    - Implement form validation and duplicate checking
    - Add automatic 1-year subscription assignment
    - _Requirements: 1.1, 1.2_

  - [ ] 4.2 Implement super admin dashboard
    - Create KPI cards for total schools, active/expired/suspended subscriptions
    - Build school listing with subscription status and days remaining
    - Add search and filter functionality for schools
    - _Requirements: 1.3_

  - [ ] 4.3 Create subscription management features
    - Implement renew subscription functionality
    - Add suspend/unsuspend school account options
    - Create school database debug access interface
    - Build subscription history tracking
    - _Requirements: 1.4, 1.5_

  - [ ] 4.4 Write super admin module tests
    - Test school registration workflow
    - Verify subscription management operations
    - Test dashboard KPI calculations
    - _Requirements: 1.1, 1.3, 1.4_

- [ ] 5. Implement school admin setup wizard
  - [ ] 5.1 Create class selection interface
    - Build multi-select form for classes (Nursery through Class 12)
    - Implement dynamic class list with checkboxes
    - Add form validation for minimum class selection
    - _Requirements: 2.2_

  - [ ] 5.2 Build fee structure configuration
    - Create fee input form for each selected class
    - Implement dynamic fee fields based on class selection
    - Add fee validation and formatting
    - _Requirements: 2.3, 5.1_

  - [ ] 5.3 Create subject assignment interface
    - Build subject selection based on class level
    - Implement appropriate subject lists for different class ranges
    - Add subject-class relationship management
    - _Requirements: 2.4_

  - [ ] 5.4 Implement setup wizard flow control
    - Create multi-step wizard navigation
    - Add progress tracking and step validation
    - Implement setup completion and dashboard redirect
    - _Requirements: 2.1, 2.5_



  - [ ] 5.5 Write setup wizard tests
    - Test wizard step navigation
    - Verify class and subject configuration
    - Test fee structure setup
    - _Requirements: 2.2, 2.3, 2.4_

- [ ] 6. Build student management module
  - [ ] 6.1 Create student enrollment interface


    - Build comprehensive student registration form
    - Implement form validation for required fields


    - Add photo upload functionality with validation
    - Create unique roll number and admission number generation
    - _Requirements: 3.1, 3.5_

  - [ ] 6.2 Implement student search and filtering
    - Create search interface with multiple filter options
    - Add filtering by name, class, admission number, roll number, phone, status
    - Implement pagination for large student lists
    - _Requirements: 3.2_

  - [ ] 6.3 Build student profile interface
    - Create detailed student profile display
    - Implement fee payment progress visualization
    - Add payment history and attendance summary sections
    - Create ID card print functionality
    - _Requirements: 3.3_

  - [ ] 6.4 Add student data export functionality
    - Implement CSV export for student lists
    - Add Excel export with formatting
    - Create filtered export based on search criteria
    - _Requirements: 3.4_

  - [ ] 6.5 Write student management tests
    - Test student enrollment workflow
    - Verify search and filtering functionality
    - Test profile display and export features
    - _Requirements: 3.1, 3.2, 3.3_

- [ ] 7. Implement attendance tracking system
  - [ ] 7.1 Create attendance interface
    - Build class-wise attendance page with student roster
    - Implement radio button interface for Present/Absent/Leave options
    - Add proper spacing and layout for up to 60 students
    - _Requirements: 4.1_

  - [ ] 7.2 Add attendance bulk operations
    - Implement "Mark All Present" functionality
    - Create "Clear All" selections option
    - Add attendance validation before saving
    - _Requirements: 4.2_

  - [ ] 7.3 Implement attendance data management
    - Create attendance record saving with date and class information
    - Add attendance modification for previously recorded dates
    - Implement attendance history tracking
    - _Requirements: 4.3, 4.4_

  - [ ] 7.4 Build attendance reporting
    - Create attendance percentage calculations
    - Implement attendance summary reports
    - Add date range filtering for attendance data
    - _Requirements: 4.5_

  - [ ] 7.5 Write attendance system tests
    - Test attendance recording workflow
    - Verify bulk operations functionality
    - Test attendance calculations and reports
    - _Requirements: 4.1, 4.2, 4.5_

- [ ] 8. Build fee management system
  - [ ] 8.1 Implement fee structure management
    - Create class-wise fee configuration interface
    - Add fee structure editing and updates
    - Implement fee validation and formatting
    - _Requirements: 5.1_

  - [ ] 8.2 Create payment recording interface
    - Build percentage-based payment calculator
    - Implement automatic amount calculation from percentage input
    - Add payment mode selection (cash/online)
    - Create payment validation and confirmation
    - _Requirements: 5.2_

  - [ ] 8.3 Implement payment tracking
    - Create payment history recording
    - Add remaining balance calculations
    - Implement payment status updates
    - Build payment receipt generation
    - _Requirements: 5.3_

  - [ ] 8.4 Add fee status visualization
    - Create fee payment progress bars
    - Implement payment status indicators
    - Add overdue payment highlighting
    - Build fee summary displays
    - _Requirements: 5.4_


  - [ ] 8.5 Integrate payment gateway
    - Add Razorpay/Stripe integration for online payments
    - Implement secure payment processing
    - Add payment confirmation and webhook handling
    - _Requirements: 5.5_

  - [ ] 8.6 Write fee management tests
    - Test payment calculation accuracy
    - Verify payment recording workflow
    - Test fee status calculations
    - _Requirements: 5.1, 5.2, 5.3_

- [ ] 9. Create dashboard and reporting system
  - [ ] 9.1 Build school admin dashboard
    - Create KPI cards for classes, fees collected, students, fees due
    - Implement real-time data calculations
    - Add color-coded status indicators
    - _Requirements: 6.1_

  - [ ] 9.2 Implement recent activities panel
    - Create activity logging system
    - Build chronological activity display
    - Add activity filtering and search
    - _Requirements: 6.2_

  - [ ] 9.3 Add subscription status indicators and renewal reminders
    - Create subscription countdown badge with real-time updates
    - Implement color-coded warnings (orange <10 days, red <3 days)
    - Add automatic email/SMS reminders 10 days and 3 days before expiry
    - Create cron job or background scheduler for subscription reminder system
    - Implement subscription renewal notifications with call-to-action
    - _Requirements: 6.3, 6.4_

  - [ ] 9.4 Build theme toggle functionality
    - Implement dark/light mode switching
    - Add persistent theme preference storage
    - Create theme-aware component styling
    - _Requirements: 6.5_

  - [ ] 9.5 Write dashboard tests
    - Test KPI calculations accuracy
    - Verify activity logging functionality
    - Test theme toggle persistence
    - _Requirements: 6.1, 6.2, 6.5_



- [ ] 10. Implement teacher management module
  - [ ] 10.1 Create teacher profile management
    - Build teacher registration and editing interface

    - Implement teacher authentication and role assignment
    - Add teacher-class assignment functionality
    - _Requirements: 7.1, 7.4_

  - [ ] 10.2 Build teacher dashboard
    - Create teacher-specific dashboard with assigned classes
    - Implement limited attendance access for assigned classes only
    - Add assignment upload functionality
    - _Requirements: 7.2_

  - [ ] 10.3 Implement teacher content management
    - Create assignment and study material upload interface
    - Add file validation and storage
    - Implement class-specific content association
    - _Requirements: 7.3_

  - [ ] 10.4 Add teacher access controls
    - Implement teacher-level permission restrictions
    - Add class-based data visibility controls
    - Create teacher activity logging
    - _Requirements: 7.5_

  - [ ] 10.5 Write teacher module tests
    - Test teacher authentication and permissions
    - Verify class assignment functionality
    - Test content upload and management
    - _Requirements: 7.1, 7.3, 7.5_

- [ ] 11. Apply Tactical Ops v2.1.7 theme and responsive design
  - [ ] 11.1 Implement base theme styling with Tactical Ops specifications
    - Apply Tactical Ops color scheme (#101010 background, #1E1E1E panels, #FF6F00 deep orange accent)
    - Implement monospaced font (Fira Code or JetBrains Mono)
    - Create base CSS variables and utility classes with proper color tokens
    - Add soft shadows and rounded corners (2xl) for cards
    - _Requirements: 6.5_

  - [ ] 11.2 Style dashboard components with theme consistency
    - Apply theme to KPI cards with soft shadows, rounded corners, and neon orange glow effects
    - Style sidebar with fixed 240px width and orange highlights for active states
    - Create rectangular buttons with uppercase text and hover glow effects
    - Implement proper contrast ratios and accessibility standards
    - _Requirements: 6.1, 6.5_

  - [ ] 11.3 Implement responsive design with mobile optimization
    - Create mobile-responsive sidebar that collapses gracefully
    - Implement responsive grid system with 8px rhythm and proper breakpoints
    - Add mobile-optimized form layouts with touch-friendly controls
    - Ensure consistent spacing and typography across all screen sizes
    - _Requirements: 6.5_

  - [ ] 11.4 Add interactive elements with Framer Motion
    - Implement Framer Motion transitions for smooth UI interactions
    - Create hover effects and micro-animations for buttons and cards
    - Add loading states and progress indicators with animated feedback
    - Implement form validation visual feedback with smooth transitions
    - Add page transition animations for better user experience
    - _Requirements: 6.5_

- [ ] 12. Implement security and validation
  - [ ] 12.1 Add input validation and sanitization
    - Implement server-side form validation for all inputs
    - Add email format validation and uniqueness checking
    - Create phone number format validation
    - Add file upload security validation
    - _Requirements: 8.1, 8.3_

  - [ ] 12.2 Implement activity logging and audit trails
    - Create comprehensive activity logging system
    - Add user action tracking for all CRUD operations
    - Implement security event logging
    - Create audit report generation
    - _Requirements: 8.5_

  - [ ] 12.3 Add rate limiting and security headers
    - Implement rate limiting for authentication endpoints
    - Add security headers for XSS and CSRF protection
    - Create session timeout and management
    - _Requirements: 8.3, 8.4_

  - [ ] 12.4 Write security tests
    - Test input validation and sanitization
    - Verify authentication security measures
    - Test file upload security
    - _Requirements: 8.1, 8.3, 8.5_

- [ ] 13. Implement notification system
  - [ ] 13.1 Create notification models and database structure
    - Create Notification model with student_id, type, method, message, status, date_sent fields
    - Add NotificationTemplate model for customizable message templates


    - Create NotificationSettings model for school-level configuration
    - _Requirements: New notification requirements_

  - [ ] 13.2 Build notification service infrastructure
    - Implement SMS service integration with Fast2SMS/TextLocal API
    - Create WhatsApp service integration with Twilio/WhatsApp Cloud API
    - Add notification queue system for reliable message delivery
    - Implement notification status tracking and retry logic
    - _Requirements: New notification requirements_

  - [ ] 13.3 Create notification settings interface
    - Build notification settings page for school admins
    - Add API key configuration forms with secure storage
    - Implement message template editor with placeholder support
    - Create enable/disable toggles for SMS and WhatsApp
    - _Requirements: New notification requirements_

  - [ ] 13.4 Implement attendance notification triggers
    - Add automatic notification sending when student is marked Absent or Leave
    - Create notification method selection UI (SMS, WhatsApp, Both)
    - Implement attendance alert message templates with placeholders
    - Add notification logging for attendance alerts
    - _Requirements: New notification requirements_

  - [ ] 13.5 Build payment notification system
    - Create automatic payment confirmation notifications
    - Implement payment receipt generation with PDF format
    - Add payment notification templates with amount and balance placeholders
    - Create fee due reminder notification scheduling
    - _Requirements: New notification requirements_

  - [ ] 13.6 Add notification management interface
    - Create notification history view for school admins
    - Implement notification status tracking and resend functionality
    - Add notification analytics and delivery reports
    - Create notification template management with preview
    - _Requirements: New notification requirements_

  - [x] 13.7 Write notification system tests

    - Test SMS and WhatsApp API integrations
    - Verify notification triggering on attendance and payment events
    - Test template rendering with placeholders
    - Verify notification delivery status tracking
    - _Requirements: New notification requirements_



- [ ] 14. Implement backup and data export module
  - [ ] 14.1 Create database export functionality
    - Implement full school data export in CSV, Excel, and JSON formats
    - Add super admin capability to export complete school database snapshots
    - Create selective data export with filtering options
    - Implement data anonymization options for privacy compliance
    - _Requirements: 1.5, 8.5_

  - [ ] 14.2 Build automated backup scheduler
    - Create configurable backup scheduler (daily/weekly/monthly)
    - Implement automated database backups with compression
    - Add backup retention policies and cleanup automation
    - Create backup verification and integrity checking
    - _Requirements: 8.5_

  - [ ] 14.3 Implement data restore functionality
    - Create super admin interface for data restoration
    - Add backup file validation and compatibility checking
    - Implement selective restore options for specific data types
    - Add restore preview and confirmation workflows
    - _Requirements: 1.5, 8.5_

  - [ ] 14.4 Add export logging and access control
    - Create comprehensive export activity logging
    - Implement role-based access control for export functions
    - Add export request approval workflows for sensitive data
    - Create export audit trails with user tracking
    - Build export analytics and usage reporting
    - _Requirements: 1.5, 8.5_

  - [ ] 14.5 Write backup and export system tests
    - Test export functionality across all data formats
    - Verify backup scheduler reliability and error handling
    - Test restore functionality with various backup scenarios
    - Verify access control and logging accuracy
    - _Requirements: 1.5, 8.5_

- [ ] 15. Integration and final testing
  - [ ] 15.1 Integrate all modules and test workflows
    - Test complete user workflows from registration to daily operations
    - Verify data consistency across all modules
    - Test role-based access across different user types
    - _Requirements: All requirements_

  - [ ] 15.2 Performance optimization and testing
    - Optimize database queries and add indexing
    - Test application performance under load
    - Implement caching for frequently accessed data
    - _Requirements: All requirements_

  - [ ] 15.3 Deploy and configure production environment
    - Set up production database and environment variables
    - Configure web server and application deployment
    - Set up monitoring and logging infrastructure
    - _Requirements: All requirements_