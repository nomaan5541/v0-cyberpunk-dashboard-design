# Design Document

## Overview

The School Management System is a web-based application built using Flask (Python) backend with SQLAlchemy ORM, HTML/CSS/JavaScript frontend, and PostgreSQL database. The system implements a multi-tenant architecture where each school operates as a separate tenant with role-based access control spanning super admin, school admin, teacher, and student/parent roles.

The application follows a modular design with clear separation between authentication, subscription management, academic operations, and reporting modules. The frontend implements the Tactical Ops v2.1.7 theme with dark mode support and responsive design.

## Architecture

### System Architecture

```mermaid
graph TB
    subgraph "Frontend Layer"
        UI[HTML/CSS/JS Templates]
        Theme[Tactical Ops Theme]
        Responsive[Responsive Components]
    end
    
    subgraph "Backend Layer"
        Flask[Flask Application]
        Auth[Authentication Module]
        Routes[Route Handlers]
        Business[Business Logic]
    end
    
    subgraph "Data Layer"
        ORM[SQLAlchemy ORM]
        DB[(PostgreSQL Database)]
        Models[Data Models]
    end
    
    subgraph "External Services"
        Payment[Payment Gateway]
        Storage[File Storage]
    end
    
    UI --> Flask
    Flask --> Auth
    Flask --> Routes
    Routes --> Business
    Business --> ORM
    ORM --> DB
    Business --> Payment
    Business --> Storage
```

### Multi-Tenant Design

The system implements schema-based multi-tenancy where:
- Super admin operates at the platform level
- Each school has isolated data within shared database tables using school_id foreign keys
- Role-based access control ensures data isolation between schools
- Subscription management controls school access at the application level

### Security Architecture

- Password hashing using bcrypt with salt rounds
- JWT-based session management with role-based claims
- Input validation and sanitization at all entry points
- SQL injection prevention through SQLAlchemy ORM
- File upload validation with type and size restrictions
- Activity logging for audit trails

## Components and Interfaces

### Authentication Component

**Purpose**: Handles user authentication, role determination, and session management

**Key Classes**:
- `AuthManager`: Handles login/logout operations
- `RoleValidator`: Validates user permissions
- `SessionManager`: Manages JWT tokens and sessions

**Interfaces**:
- `authenticate(email, password) -> User`
- `validate_role(user, required_role) -> boolean`
- `create_session(user) -> token`

### Subscription Management Component

**Purpose**: Manages school subscriptions, renewals, and access control

**Key Classes**:
- `SubscriptionManager`: Handles subscription operations
- `AccessController`: Controls feature access based on subscription status
- `NotificationService`: Sends subscription alerts

**Interfaces**:
- `create_subscription(school_id, duration) -> Subscription`
- `check_access(school_id) -> boolean`
- `get_days_remaining(school_id) -> integer`

### Academic Management Component

**Purpose**: Handles student enrollment, attendance, and academic operations

**Key Classes**:
- `StudentManager`: CRUD operations for students
- `AttendanceTracker`: Daily attendance recording and reporting
- `ClassManager`: Class and subject configuration

**Interfaces**:
- `enroll_student(student_data) -> Student`
- `record_attendance(class_id, date, attendance_data) -> boolean`
- `get_class_roster(class_id) -> List[Student]`

### Fee Management Component

**Purpose**: Manages fee structure, payment recording, and financial tracking

**Key Classes**:
- `FeeCalculator`: Calculates payments and balances
- `PaymentProcessor`: Records and validates payments
- `FinancialReporter`: Generates fee reports

**Interfaces**:
- `calculate_payment(fee_amount, percentage) -> amount`
- `record_payment(student_id, amount, mode) -> Payment`
- `get_payment_status(student_id) -> PaymentStatus`

### Dashboard Component

**Purpose**: Provides KPI visualization and system overview

**Key Classes**:
- `DashboardBuilder`: Constructs dashboard data
- `KPICalculator`: Computes key performance indicators
- `ActivityLogger`: Tracks and displays recent activities

**Interfaces**:
- `get_dashboard_data(school_id) -> DashboardData`
- `calculate_kpis(school_id) -> KPIMetrics`
- `log_activity(user_id, action, details) -> ActivityLog`

## Data Models

### Core Entity Relationships

```mermaid
erDiagram
    users ||--o{ schools : manages
    schools ||--o{ classes : contains
    classes ||--o{ students : enrolled_in
    classes ||--o{ subjects : teaches
    students ||--o{ attendance : records
    students ||--o{ payments : makes
    schools ||--o{ fee_structures : defines
    users ||--o{ activity_logs : creates
    
    users {
        int id PK
        string name
        string email UK
        string password_hash
        enum role
        timestamp created_at
    }
    
    schools {
        int id PK
        string name
        string email UK
        string phone
        date subscription_start
        date subscription_end
        enum status
        timestamp created_at
    }
    
    classes {
        int id PK
        int school_id FK
        string class_name
        int capacity
        timestamp created_at
    }
    
    students {
        int id PK
        int class_id FK
        string roll_number UK
        string admission_no UK
        string name
        string father_name
        string mother_name
        enum gender
        date date_of_birth
        string phone
        text address
        string photo_url
        enum status
        date admission_date
        timestamp created_at
    }
    
    attendance {
        int id PK
        int school_id FK
        int class_id FK
        int student_id FK
        date attendance_date
        enum status
        timestamp created_at
    }
    
    payments {
        int id PK
        int student_id FK
        decimal amount
        decimal percentage_paid
        enum payment_mode
        date payment_date
        string reference_id
        timestamp created_at
    }
```

### Data Validation Rules

- Email addresses must be unique across users and schools
- Roll numbers and admission numbers must be unique within each school
- Phone numbers must follow valid format (10 digits)
- Dates must be validated for logical consistency (DOB < admission date)
- Percentage payments must be between 0-100
- File uploads limited to specific types and sizes

## Error Handling

### Error Categories

1. **Validation Errors**: Invalid input data, format violations
2. **Authentication Errors**: Invalid credentials, expired sessions
3. **Authorization Errors**: Insufficient permissions, role violations
4. **Business Logic Errors**: Subscription expired, duplicate enrollment
5. **System Errors**: Database connectivity, file system issues

### Error Response Strategy

```python
class ErrorResponse:
    def __init__(self, error_type, message, details=None):
        self.error_type = error_type
        self.message = message
        self.details = details
        self.timestamp = datetime.utcnow()
    
    def to_json(self):
        return {
            'error': self.error_type,
            'message': self.message,
            'details': self.details,
            'timestamp': self.timestamp.isoformat()
        }
```

### Logging Strategy

- All errors logged with severity levels (ERROR, WARN, INFO)
- User actions logged for audit trails
- Performance metrics logged for monitoring
- Security events logged with enhanced detail
- Log rotation and retention policies implemented

## Testing Strategy

### Unit Testing

- **Model Testing**: Validate data model constraints and relationships
- **Service Testing**: Test business logic components in isolation
- **Utility Testing**: Verify helper functions and calculations
- **Validation Testing**: Ensure input validation works correctly

**Framework**: pytest with fixtures for database setup

### Integration Testing

- **API Testing**: Validate REST endpoints with various inputs
- **Database Testing**: Verify ORM operations and transactions
- **Authentication Testing**: Test login flows and role validation
- **File Upload Testing**: Validate file handling and storage

**Tools**: pytest-flask for Flask application testing

### Frontend Testing

- **UI Component Testing**: Validate form submissions and interactions
- **Theme Testing**: Verify dark/light mode functionality
- **Responsive Testing**: Ensure mobile compatibility
- **Accessibility Testing**: Validate WCAG compliance

**Approach**: Manual testing with browser automation for critical paths

### Performance Testing

- **Load Testing**: Simulate concurrent user sessions
- **Database Performance**: Test query optimization
- **File Upload Performance**: Validate large file handling
- **Memory Usage**: Monitor application resource consumption

**Metrics**: Response time < 2s for 95% of requests, support 100 concurrent users

### Security Testing

- **Authentication Testing**: Verify password security and session management
- **Authorization Testing**: Ensure role-based access controls
- **Input Validation Testing**: Test for SQL injection and XSS vulnerabilities
- **File Upload Security**: Validate malicious file detection

**Tools**: Manual security review with automated vulnerability scanning

### Test Data Management

- **Fixtures**: Predefined test data for consistent testing
- **Factories**: Dynamic test data generation for various scenarios
- **Cleanup**: Automated test data cleanup after test execution
- **Isolation**: Each test runs with clean database state

### Continuous Integration

- **Automated Testing**: All tests run on code commits
- **Coverage Requirements**: Minimum 80% code coverage for core modules
- **Quality Gates**: Tests must pass before deployment
- **Performance Benchmarks**: Automated performance regression detection