# Design Document

## Overview

This design outlines the implementation of a consistent Tactical Ops v2.1.7 theme across all pages of the School Management System. The current system has inconsistent theme application with approximately 23 templates not using the base template inheritance, and the login page using completely custom CSS. This design will establish a unified theming system that ensures visual consistency and maintainability.

## Architecture

### Template Inheritance Structure

```
base.html (Enhanced)
├── auth/
│   ├── login.html (Refactored)
│   ├── super_login.html (Refactored)
│   └── simple_login.html (Refactored)
├── dashboard_base.html (New)
│   ├── student/dashboard.html
│   ├── teacher/dashboard.html
│   ├── school_admin/dashboard.html
│   └── super_admin/dashboard.html
├── form_base.html (New)
│   ├── student/profile.html
│   ├── teacher/profile.html
│   └── school_admin/add_student.html
└── content_base.html (New)
    ├── student/assignments.html
    ├── teacher/assignments.html
    └── All other content pages
```

### Theme Asset Management

- **Primary CSS**: `tactical-ops.css` (already exists and comprehensive)
- **Base Template**: Enhanced to include all theme dependencies
- **Specialized Templates**: Dashboard, form, and content base templates for specific layouts
- **JavaScript**: Centralized theme-related JavaScript in `app.js`

## Components and Interfaces

### 1. Enhanced Base Template (`base.html`)

**Purpose**: Provide core theme foundation for all templates

**Key Features**:
- Tactical Ops CSS inclusion
- Font loading (JetBrains Mono, Fira Code)
- CSS custom properties setup
- Flash message system with theme styling
- Mobile-responsive meta tags
- Theme JavaScript initialization

**Template Blocks**:
```html
{% block title %}
{% block extra_css %}
{% block body_class %}
{% block content %}
{% block extra_js %}
```

### 2. Dashboard Base Template (`dashboard_base.html`)

**Purpose**: Specialized template for dashboard layouts with sidebar navigation

**Key Features**:
- Sidebar navigation component
- Main content area with proper spacing
- KPI card grid system
- Dashboard-specific JavaScript
- Responsive sidebar behavior

**Template Structure**:
```html
{% extends "base.html" %}
{% block content %}
<div class="dashboard-container">
    <nav class="sidebar">{% block sidebar %}{% endblock %}</nav>
    <main class="main-content">{% block main_content %}{% endblock %}</main>
</div>
{% endblock %}
```

### 3. Form Base Template (`form_base.html`)

**Purpose**: Specialized template for form-heavy pages

**Key Features**:
- Form styling consistency
- Input validation styling
- Button styling standardization
- Form layout utilities

### 4. Content Base Template (`content_base.html`)

**Purpose**: General content pages with consistent layout

**Key Features**:
- Content area styling
- Table styling
- Card layouts
- List styling

## Data Models

### Theme Configuration Object

```javascript
const themeConfig = {
    colors: {
        primary: '#FF6F00',
        primaryHover: '#E55A00',
        background: '#101010',
        surface: '#1E1E1E',
        tertiary: '#2A2A2A',
        text: '#FFFFFF',
        textSecondary: '#CCCCCC',
        textMuted: '#999999'
    },
    breakpoints: {
        mobile: '768px',
        tablet: '1024px',
        desktop: '1200px'
    },
    animations: {
        duration: '0.2s',
        easing: 'ease'
    }
};
```

### Template Context Variables

Each template will receive consistent context variables for theme-related data:
- `theme_config`: Theme configuration object
- `current_user_role`: For role-specific styling
- `page_title`: For consistent page titles
- `breadcrumbs`: For navigation context

## Error Handling

### Template Fallbacks

1. **Missing CSS**: Graceful degradation to browser defaults
2. **JavaScript Errors**: Progressive enhancement approach
3. **Font Loading Failures**: Fallback to system fonts
4. **Image Loading**: Placeholder styling for missing assets

### Theme Validation

```python
def validate_theme_assets():
    """Validate that all theme assets are available"""
    required_assets = [
        'static/css/tactical-ops.css',
        'static/js/app.js'
    ]
    for asset in required_assets:
        if not os.path.exists(asset):
            logger.warning(f"Theme asset missing: {asset}")
```

## Testing Strategy

### Visual Regression Testing

1. **Page Screenshots**: Capture screenshots of all major pages
2. **Component Testing**: Test individual UI components
3. **Responsive Testing**: Verify mobile, tablet, and desktop layouts
4. **Cross-browser Testing**: Ensure consistency across browsers

### Automated Testing

```python
def test_theme_consistency():
    """Test that all templates use consistent theme classes"""
    templates = get_all_templates()
    for template in templates:
        assert 'tactical-ops.css' in template.assets
        assert template.extends_base_template()
```

### Manual Testing Checklist

- [ ] All pages load with consistent styling
- [ ] Navigation works across all user roles
- [ ] Forms use consistent styling
- [ ] Buttons have consistent appearance and behavior
- [ ] Colors match theme specification
- [ ] Typography is consistent
- [ ] Responsive design works on all screen sizes
- [ ] Animations and transitions are smooth
- [ ] Flash messages display correctly
- [ ] Loading states are properly styled

## Implementation Phases

### Phase 1: Base Template Enhancement
- Enhance `base.html` with complete theme integration
- Create specialized base templates (dashboard, form, content)
- Update CSS to ensure all theme components are available

### Phase 2: Authentication Pages
- Refactor login page to use base template
- Remove custom CSS from auth templates
- Implement consistent form styling

### Phase 3: Dashboard Pages
- Convert all dashboard pages to use `dashboard_base.html`
- Standardize sidebar navigation
- Implement consistent KPI card styling

### Phase 4: Content Pages
- Convert remaining templates to use appropriate base templates
- Standardize table, form, and content styling
- Ensure consistent navigation patterns

### Phase 5: Testing and Refinement
- Conduct visual regression testing
- Fix any styling inconsistencies
- Optimize performance
- Document theme usage guidelines

## Performance Considerations

### CSS Optimization
- Minimize CSS file size through optimization
- Use CSS custom properties for theme values
- Implement critical CSS inlining for above-the-fold content

### JavaScript Optimization
- Lazy load non-critical JavaScript
- Minimize DOM manipulation
- Use efficient event delegation

### Asset Loading
- Implement proper caching headers
- Use CDN for external fonts
- Optimize image assets

## Accessibility Compliance

### Color Contrast
- Ensure all text meets WCAG AA contrast requirements
- Provide high contrast mode option
- Use semantic color meanings

### Keyboard Navigation
- Ensure all interactive elements are keyboard accessible
- Implement proper focus indicators
- Maintain logical tab order

### Screen Reader Support
- Use semantic HTML elements
- Provide proper ARIA labels
- Ensure content is properly structured

## Browser Compatibility

### Supported Browsers
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

### Fallback Strategies
- CSS Grid fallbacks for older browsers
- JavaScript polyfills for missing features
- Progressive enhancement approach

## Maintenance Guidelines

### Theme Updates
- Use CSS custom properties for easy theme modifications
- Maintain theme documentation
- Version control theme changes

### Template Guidelines
- Always extend appropriate base template
- Use theme utility classes instead of custom CSS
- Follow consistent naming conventions
- Document any theme customizations