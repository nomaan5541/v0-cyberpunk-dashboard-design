"""
School Admin Blueprint - Handles school operations and management
"""
from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from extensions import db
from models.user import User
from models.school import School
from utils.auth import login_required, role_required

school_admin_bp = Blueprint('school_admin', __name__)


@school_admin_bp.route('/dashboard')
@role_required('school_admin')
def dashboard():
    """School admin dashboard"""
    user = User.query.get(session['user_id'])
    school = School.query.get(user.school_id)
    
    # Check if setup wizard is completed
    if not school.setup_completed:
        return redirect(url_for('school_admin.setup_wizard'))
    
    # Calculate KPIs (placeholder for now)
    classes_active = 0
    fees_collected = 0
    registered_students = 0
    fees_due = 0
    
    return render_template('school_admin/dashboard.html',
                         school=school,
                         classes_active=classes_active,
                         fees_collected=fees_collected,
                         registered_students=registered_students,
                         fees_due=fees_due)


# Removed duplicate setup_wizard function - using the more complete one below


@school_admin_bp.route('/students')
@role_required('school_admin')
def students():
    """List all students"""
    user = User.query.get(session['user_id'])
    school = School.query.get(user.school_id)
    
    # Get search and filter parameters
    search = request.args.get('search', '')
    class_filter = request.args.get('class', '')
    status_filter = request.args.get('status', '')
    page = request.args.get('page', 1, type=int)
    
    # Build query
    from models.student import Student
    from models.classes import Class
    
    query = Student.query.filter_by(school_id=school.id)
    
    # Apply filters
    if search:
        query = query.filter(
            db.or_(
                Student.name.contains(search),
                Student.admission_no.contains(search),
                Student.roll_number.contains(search),
                Student.phone.contains(search)
            )
        )
    
    if class_filter:
        query = query.filter_by(class_id=class_filter)
    
    if status_filter:
        query = query.filter_by(status=status_filter)
    
    # Paginate results
    students = query.order_by(Student.created_at.desc()).paginate(
        page=page, per_page=25, error_out=False
    )
    
    # Get classes for filter dropdown
    classes = Class.query.filter_by(school_id=school.id).all()
    
    return render_template('school_admin/students.html', 
                         students=students, 
                         classes=classes,
                         search=search,
                         class_filter=class_filter,
                         status_filter=status_filter)


@school_admin_bp.route('/students/add', methods=['GET', 'POST'])
@role_required('school_admin')
def add_student():
    """Add new student"""
    user = User.query.get(session['user_id'])
    school = School.query.get(user.school_id)
    
    if request.method == 'POST':
        from models.student import Student, StudentStatus
        from models.classes import Class
        from datetime import datetime
        
        try:
            # Get form data
            student_data = {
                'school_id': school.id,
                'class_id': request.form.get('class_id') or None,
                'roll_number': request.form.get('roll_number'),
                'admission_no': request.form.get('admission_no'),
                'admission_date': datetime.strptime(request.form.get('admission_date'), '%Y-%m-%d').date(),
                'name': request.form.get('name'),
                'father_name': request.form.get('father_name'),
                'mother_name': request.form.get('mother_name'),
                'gender': request.form.get('gender'),
                'date_of_birth': datetime.strptime(request.form.get('date_of_birth'), '%Y-%m-%d').date(),
                'phone': request.form.get('phone'),
                'email': request.form.get('email') or None,
                'address': request.form.get('address'),
                'blood_group': request.form.get('blood_group') or None,
                'pen_no': request.form.get('pen_no') or None,
                'bio': request.form.get('bio') or None,
                'status': StudentStatus.ACTIVE
            }
            
            # Create student
            student = Student(**student_data)
            db.session.add(student)
            db.session.commit()
            
            flash(f'Student {student.name} added successfully!', 'success')
            return redirect(url_for('school_admin.students'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding student: {str(e)}', 'error')
    
    # Get classes for dropdown
    from models.classes import Class
    classes = Class.query.filter_by(school_id=school.id).all()
    
    return render_template('school_admin/add_student.html', classes=classes)


@school_admin_bp.route('/students/<int:student_id>')
@role_required('school_admin')
def student_profile(student_id):
    """View student profile"""
    user = User.query.get(session['user_id'])
    school = School.query.get(user.school_id)
    
    from models.student import Student
    student = Student.query.filter_by(id=student_id, school_id=school.id).first_or_404()
    
    return render_template('school_admin/student_profile.html', student=student)


@school_admin_bp.route('/students/<int:student_id>/edit', methods=['GET', 'POST'])
@role_required('school_admin')
def edit_student(student_id):
    """Edit student information"""
    user = User.query.get(session['user_id'])
    school = School.query.get(user.school_id)
    
    from models.student import Student, StudentStatus
    from models.classes import Class
    
    student = Student.query.filter_by(id=student_id, school_id=school.id).first_or_404()
    
    if request.method == 'POST':
        try:
            from datetime import datetime
            
            # Update student data
            student.class_id = request.form.get('class_id') or None
            student.roll_number = request.form.get('roll_number')
            student.admission_no = request.form.get('admission_no')
            student.admission_date = datetime.strptime(request.form.get('admission_date'), '%Y-%m-%d').date()
            student.name = request.form.get('name')
            student.father_name = request.form.get('father_name')
            student.mother_name = request.form.get('mother_name')
            student.gender = request.form.get('gender')
            student.date_of_birth = datetime.strptime(request.form.get('date_of_birth'), '%Y-%m-%d').date()
            student.phone = request.form.get('phone')
            student.email = request.form.get('email') or None
            student.address = request.form.get('address')
            student.blood_group = request.form.get('blood_group') or None
            student.pen_no = request.form.get('pen_no') or None
            student.bio = request.form.get('bio') or None
            student.status = StudentStatus(request.form.get('status'))
            
            db.session.commit()
            
            flash(f'Student {student.name} updated successfully!', 'success')
            return redirect(url_for('school_admin.student_profile', student_id=student.id))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating student: {str(e)}', 'error')
    
    # Get classes for dropdown
    classes = Class.query.filter_by(school_id=school.id).all()
    
    return render_template('school_admin/edit_student.html', student=student, classes=classes)

@school_admin_bp.route('/attendance', methods=['GET', 'POST'])
@role_required('school_admin')
def attendance():
    """Mark attendance for students"""
    user = User.query.get(session['user_id'])
    school = School.query.get(user.school_id)
    
    from models.classes import Class
    from models.student import Student
    from models.attendance import Attendance, AttendanceStatus
    from datetime import datetime, date
    
    # Get classes for dropdown
    classes = Class.query.filter_by(school_id=school.id).all()
    
    selected_date = None
    selected_class_id = None
    selected_class = None
    students = []
    attendance_data = {}
    
    if request.method == 'POST':
        # Handle attendance submission
        try:
            selected_date = datetime.strptime(request.form.get('date'), '%Y-%m-%d').date()
            selected_class_id = int(request.form.get('class_id'))
            
            # Get all students in the class
            students = Student.query.filter_by(school_id=school.id, class_id=selected_class_id).all()
            
            # Process attendance data
            for student in students:
                attendance_status = request.form.get(f'attendance_{student.id}')
                if attendance_status:
                    # Check if attendance already exists for this date
                    existing_attendance = Attendance.query.filter_by(
                        student_id=student.id,
                        date=selected_date
                    ).first()
                    
                    if existing_attendance:
                        # Update existing attendance
                        existing_attendance.status = AttendanceStatus(attendance_status)
                        existing_attendance.marked_by = user.id
                        existing_attendance.marked_at = datetime.utcnow()
                    else:
                        # Create new attendance record
                        attendance = Attendance(
                            school_id=school.id,
                            student_id=student.id,
                            class_id=selected_class_id,
                            date=selected_date,
                            status=AttendanceStatus(attendance_status),
                            marked_by=user.id
                        )
                        db.session.add(attendance)
            
            db.session.commit()
            flash('Attendance saved successfully!', 'success')
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error saving attendance: {str(e)}', 'error')
    
    # Handle GET request with date and class selection
    if request.args.get('date') and request.args.get('class_id'):
        try:
            selected_date = datetime.strptime(request.args.get('date'), '%Y-%m-%d').date()
            selected_class_id = int(request.args.get('class_id'))
            selected_class = Class.query.get(selected_class_id)
            
            # Get students for the selected class
            students = Student.query.filter_by(school_id=school.id, class_id=selected_class_id).all()
            
            # Get existing attendance data for the date
            existing_attendance = Attendance.query.filter_by(
                school_id=school.id,
                class_id=selected_class_id,
                date=selected_date
            ).all()
            
            # Create attendance data dictionary
            for att in existing_attendance:
                attendance_data[att.student_id] = att.status.value
                
        except Exception as e:
            flash(f'Error loading attendance data: {str(e)}', 'error')
    
    return render_template('school_admin/attendance.html',
                         classes=classes,
                         selected_date=selected_date,
                         selected_class_id=selected_class_id,
                         selected_class=selected_class,
                         students=students,
                         attendance_data=attendance_data)


@school_admin_bp.route('/fees')
@role_required('school_admin')
def fees():
    """Fee management dashboard"""
    user = User.query.get(session['user_id'])
    school = School.query.get(user.school_id)
    
    from models.classes import Class
    from models.student import Student
    from models.fee import StudentFeeStatus, Payment
    from decimal import Decimal
    from datetime import datetime, date
    
    # Calculate fee summary
    fee_summary = {
        'total_due': Decimal('0.00'),
        'total_collected': Decimal('0.00'),
        'this_month': Decimal('0.00'),
        'overdue_count': 0
    }
    
    # Get all student fee statuses
    student_fees = StudentFeeStatus.query.filter_by(school_id=school.id).all()
    
    for fee_status in student_fees:
        fee_summary['total_due'] += fee_status.remaining_amount
        fee_summary['total_collected'] += fee_status.paid_amount
        if fee_status.is_overdue:
            fee_summary['overdue_count'] += 1
    
    # Calculate this month's collections
    this_month_payments = Payment.query.filter(
        Payment.school_id == school.id,
        Payment.payment_date >= date.today().replace(day=1)
    ).all()
    
    for payment in this_month_payments:
        fee_summary['this_month'] += payment.amount
    
    # Get classes for filter
    classes = Class.query.filter_by(school_id=school.id).all()
    
    return render_template('school_admin/fees.html',
                         fee_summary=fee_summary,
                         student_fees=student_fees,
                         classes=classes)


@school_admin_bp.route('/record_payment', methods=['POST'])
@role_required('school_admin')
def record_payment():
    """Record a fee payment"""
    user = User.query.get(session['user_id'])
    school = School.query.get(user.school_id)
    
    from models.student import Student
    from models.fee import Payment, PaymentMode, PaymentStatus, StudentFeeStatus, FeeStructure
    from utils.helpers import generate_receipt_number
    from decimal import Decimal
    from datetime import datetime, date
    
    try:
        student_id = int(request.form.get('student_id'))
        amount = Decimal(request.form.get('amount'))
        payment_mode = PaymentMode(request.form.get('payment_mode'))
        remarks = request.form.get('remarks', '')
        
        # Get student and fee structure
        student = Student.query.filter_by(id=student_id, school_id=school.id).first_or_404()
        fee_structure = FeeStructure.query.filter_by(
            school_id=school.id,
            class_id=student.class_id,
            is_active=True
        ).first()
        
        if not fee_structure:
            flash('No active fee structure found for this student', 'error')
            return redirect(url_for('school_admin.fees'))
        
        # Create payment record
        payment = Payment(
            school_id=school.id,
            student_id=student_id,
            fee_structure_id=fee_structure.id,
            receipt_no=generate_receipt_number(school.id),
            amount=amount,
            payment_date=date.today(),
            payment_mode=payment_mode,
            status=PaymentStatus.COMPLETED,
            remarks=remarks,
            collected_by=user.id
        )
        db.session.add(payment)
        
        # Update student fee status
        fee_status = StudentFeeStatus.query.filter_by(
            student_id=student_id,
            fee_structure_id=fee_structure.id
        ).first()
        
        if fee_status:
            fee_status.paid_amount += amount
            fee_status.last_payment_date = date.today()
            fee_status.calculate_status()
        else:
            # Create new fee status
            fee_status = StudentFeeStatus(
                school_id=school.id,
                student_id=student_id,
                fee_structure_id=fee_structure.id,
                total_fee=fee_structure.total_fee,
                paid_amount=amount,
                remaining_amount=fee_structure.total_fee - amount,
                last_payment_date=date.today()
            )
            fee_status.calculate_status()
            db.session.add(fee_status)
        
        db.session.commit()
        
        flash(f'Payment of ₹{amount} recorded successfully! Receipt: {payment.receipt_no}', 'success')
        
        # Send payment notification if enabled
        try:
            from utils.notification_service import NotificationService
            notification_service = NotificationService(school.id)
            notification_service.send_payment_confirmation(student, payment)
        except Exception as e:
            # Don't fail the payment if notification fails
            print(f"Notification error: {e}")
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error recording payment: {str(e)}', 'error')
    
    return redirect(url_for('school_admin.fees'))


@school_admin_bp.route('/teachers')
@role_required('school_admin')
def teachers():
    """List all teachers"""
    user = User.query.get(session['user_id'])
    school = School.query.get(user.school_id)
    
    # Get search and filter parameters
    search = request.args.get('search', '')
    subject_filter = request.args.get('subject', '')
    status_filter = request.args.get('status', '')
    page = request.args.get('page', 1, type=int)
    
    # Build query
    from models.teacher import Teacher
    from models.classes import Subject
    
    query = Teacher.query.filter_by(school_id=school.id)
    
    # Apply filters
    if search:
        query = query.filter(
            db.or_(
                Teacher.name.contains(search),
                Teacher.employee_id.contains(search),
                Teacher.phone.contains(search),
                Teacher.email.contains(search)
            )
        )
    
    if subject_filter:
        query = query.filter(Teacher.subjects.any(Subject.id == subject_filter))
    
    if status_filter:
        query = query.filter_by(status=status_filter)
    
    # Paginate results
    teachers = query.order_by(Teacher.created_at.desc()).paginate(
        page=page, per_page=25, error_out=False
    )
    
    # Get subjects for filter dropdown
    subjects = Subject.query.filter_by(school_id=school.id).all()
    
    return render_template('school_admin/teachers.html', 
                         teachers=teachers, 
                         subjects=subjects,
                         search=search,
                         subject_filter=subject_filter,
                         status_filter=status_filter)


@school_admin_bp.route('/classes')
@role_required('school_admin')
def classes():
    """List all classes"""
    user = User.query.get(session['user_id'])
    school = School.query.get(user.school_id)
    
    # Get search and filter parameters
    search = request.args.get('search', '')
    academic_year_filter = request.args.get('academic_year', '')
    page = request.args.get('page', 1, type=int)
    
    # Build query
    from models.classes import Class
    from models.student import Student
    
    query = Class.query.filter_by(school_id=school.id)
    
    # Apply filters
    if search:
        query = query.filter(
            db.or_(
                Class.class_name.contains(search),
                Class.section.contains(search)
            )
        )
    
    if academic_year_filter:
        query = query.filter_by(academic_year=academic_year_filter)
    
    # Paginate results
    classes = query.order_by(Class.class_name, Class.section).paginate(
        page=page, per_page=25, error_out=False
    )
    
    # Add student count to each class
    for class_obj in classes.items:
        class_obj.student_count = Student.query.filter_by(class_id=class_obj.id).count()
    
    # Get academic years for filter dropdown
    academic_years = db.session.query(Class.academic_year).filter_by(school_id=school.id).distinct().all()
    academic_years = [year[0] for year in academic_years]
    
    return render_template('school_admin/classes.html', 
                         classes=classes, 
                         academic_years=academic_years,
                         search=search,
                         academic_year_filter=academic_year_filter)


@school_admin_bp.route('/reports')
@role_required('school_admin')
def reports():
    """Reports dashboard"""
    user = User.query.get(session['user_id'])
    school = School.query.get(user.school_id)
    
    from models.student import Student
    from models.teacher import Teacher
    from models.classes import Class
    from models.fee import Payment, StudentFeeStatus
    from models.attendance import Attendance, AttendanceStatus
    from datetime import datetime, date, timedelta
    from decimal import Decimal
    
    # Calculate basic statistics
    stats = {
        'total_students': Student.query.filter_by(school_id=school.id).count(),
        'total_teachers': Teacher.query.filter_by(school_id=school.id).count(),
        'total_classes': Class.query.filter_by(school_id=school.id).count(),
        'total_revenue': Decimal('0.00'),
        'attendance_rate': 0.0
    }
    
    # Calculate revenue
    payments = Payment.query.filter_by(school_id=school.id).all()
    stats['total_revenue'] = sum(payment.amount for payment in payments)
    
    # Calculate attendance rate for last 30 days
    thirty_days_ago = date.today() - timedelta(days=30)
    total_attendance = Attendance.query.filter(
        Attendance.school_id == school.id,
        Attendance.date >= thirty_days_ago
    ).count()
    
    present_attendance = Attendance.query.filter(
        Attendance.school_id == school.id,
        Attendance.date >= thirty_days_ago,
        Attendance.status == AttendanceStatus.PRESENT
    ).count()
    
    if total_attendance > 0:
        stats['attendance_rate'] = (present_attendance / total_attendance) * 100
    
    # Get recent activities (placeholder)
    recent_activities = []
    
    return render_template('school_admin/reports.html', 
                         stats=stats,
                         recent_activities=recent_activities)


@school_admin_bp.route('/students/<int:student_id>/delete', methods=['POST'])
@role_required('school_admin')
def delete_student(student_id):
    """Delete a student"""
    user = User.query.get(session['user_id'])
    school = School.query.get(user.school_id)
    
    from models.student import Student
    
    try:
        student = Student.query.filter_by(id=student_id, school_id=school.id).first_or_404()
        student_name = student.name
        
        # Delete related records first
        from models.attendance import Attendance
        from models.fee import Payment, StudentFeeStatus
        
        # Delete attendance records
        Attendance.query.filter_by(student_id=student_id).delete()
        
        # Delete payment records
        Payment.query.filter_by(student_id=student_id).delete()
        
        # Delete fee status records
        StudentFeeStatus.query.filter_by(student_id=student_id).delete()
        
        # Delete the student
        db.session.delete(student)
        db.session.commit()
        
        flash(f'Student {student_name} deleted successfully!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting student: {str(e)}', 'error')
    
    return redirect(url_for('school_admin.students'))


@school_admin_bp.route('/setup_wizard', methods=['GET', 'POST'])
@role_required('school_admin')
def setup_wizard():
    """Setup wizard for new schools"""
    user = User.query.get(session['user_id'])
    school = School.query.get(user.school_id)
    
    from models.classes import Class, Subject
    from models.fee import FeeStructure
    from utils.helpers import get_available_classes, get_class_subjects
    from decimal import Decimal
    
    # Get current step
    step = int(request.args.get('step', 1))
    
    # Initialize session data
    if 'setup_data' not in session:
        session['setup_data'] = {}
    
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'next' or action == 'complete':
            # Save current step data
            if step == 1:
                # Save selected classes
                selected_classes = request.form.getlist('selected_classes')
                if not selected_classes:
                    flash('Please select at least one class', 'error')
                    return redirect(url_for('school_admin.setup_wizard', step=1))
                session['setup_data']['selected_classes'] = selected_classes
                
            elif step == 2:
                # Save fee structure
                fees = {}
                installments = {}
                for class_name in session['setup_data']['selected_classes']:
                    fee_key = f"fee_{class_name.replace(' ', '_')}"
                    installment_key = f"installments_{class_name.replace(' ', '_')}"
                    
                    fee_amount = request.form.get(fee_key)
                    installment_count = request.form.get(installment_key)
                    
                    if not fee_amount or float(fee_amount) <= 0:
                        flash(f'Please enter valid fee for {class_name}', 'error')
                        return redirect(url_for('school_admin.setup_wizard', step=2))
                    
                    fees[class_name] = float(fee_amount)
                    installments[class_name] = int(installment_count)
                
                session['setup_data']['fees'] = fees
                session['setup_data']['installments'] = installments
                
            elif step == 3:
                # Save subjects
                subjects = {}
                for class_name in session['setup_data']['selected_classes']:
                    subject_key = f"subjects_{class_name.replace(' ', '_')}"
                    selected_subjects = request.form.getlist(subject_key)
                    subjects[class_name] = selected_subjects
                
                session['setup_data']['subjects'] = subjects
            
            # Move to next step or complete setup
            if action == 'complete':
                # Create classes, subjects, and fee structures
                try:
                    academic_year = "2024-25"  # Current academic year
                    
                    for class_name in session['setup_data']['selected_classes']:
                        # Create class
                        new_class = Class(
                            school_id=school.id,
                            class_name=class_name,
                            section="A",  # Default section
                            capacity=60,
                            academic_year=academic_year
                        )
                        db.session.add(new_class)
                        db.session.flush()  # Get class ID
                        
                        # Create subjects for this class
                        if class_name in session['setup_data']['subjects']:
                            for subject_name in session['setup_data']['subjects'][class_name]:
                                subject = Subject(
                                    school_id=school.id,
                                    class_id=new_class.id,
                                    name=subject_name,
                                    code=subject_name[:3].upper()
                                )
                                db.session.add(subject)
                        
                        # Create fee structure
                        if class_name in session['setup_data']['fees']:
                            fee_structure = FeeStructure(
                                school_id=school.id,
                                class_id=new_class.id,
                                academic_year=academic_year,
                                total_fee=Decimal(str(session['setup_data']['fees'][class_name])),
                                tuition_fee=Decimal(str(session['setup_data']['fees'][class_name] * 0.7)),  # 70% tuition
                                admission_fee=Decimal(str(session['setup_data']['fees'][class_name] * 0.1)),  # 10% admission
                                development_fee=Decimal(str(session['setup_data']['fees'][class_name] * 0.1)),  # 10% development
                                other_fee=Decimal(str(session['setup_data']['fees'][class_name] * 0.1)),  # 10% other
                                installments=session['setup_data']['installments'][class_name],
                                is_active=True
                            )
                            db.session.add(fee_structure)
                    
                    # Mark setup as completed
                    school.setup_completed = True
                    db.session.commit()
                    
                    # Clear setup data
                    session.pop('setup_data', None)
                    
                    flash('School setup completed successfully!', 'success')
                    return redirect(url_for('school_admin.dashboard'))
                    
                except Exception as e:
                    db.session.rollback()
                    flash(f'Error completing setup: {str(e)}', 'error')
                    return redirect(url_for('school_admin.setup_wizard', step=3))
            else:
                # Move to next step
                return redirect(url_for('school_admin.setup_wizard', step=step + 1))
        
        elif action == 'previous':
            return redirect(url_for('school_admin.setup_wizard', step=step - 1))
    
    # Prepare template data
    template_data = {
        'step': step,
        'progress': (step / 3) * 100,
        'available_classes': get_available_classes(),
        'selected_classes': session['setup_data'].get('selected_classes', []),
        'fees': session['setup_data'].get('fees', {}),
        'installments': session['setup_data'].get('installments', {}),
        'class_subjects': {}
    }
    
    # Get subjects for selected classes
    if 'selected_classes' in session['setup_data']:
        for class_name in session['setup_data']['selected_classes']:
            template_data['class_subjects'][class_name] = get_class_subjects(class_name)
    
    return render_template('school_admin/setup_wizard.html', **template_data)


@school_admin_bp.route('/settings')
@role_required('school_admin')
def settings():
    """School settings page"""
    user = User.query.get(session['user_id'])
    school = School.query.get(user.school_id)
    
    return render_template('school_admin/settings.html', school=school)