"""
PDF Generator - Generate PDFs for receipts, reports, and ID cards
"""
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.graphics.shapes import Drawing, Rect
from reportlab.graphics import renderPDF
import qrcode
from io import BytesIO
import os
from datetime import datetime


class PDFGenerator:
    """PDF generation utilities"""
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self.setup_custom_styles()
    
    def setup_custom_styles(self):
        """Setup custom paragraph styles"""
        self.styles.add(ParagraphStyle(
            name='CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=18,
            spaceAfter=30,
            alignment=TA_CENTER,
            textColor=colors.HexColor('#FF6F00')
        ))
        
        self.styles.add(ParagraphStyle(
            name='CustomHeading',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceAfter=12,
            textColor=colors.HexColor('#FF6F00')
        ))
        
        self.styles.add(ParagraphStyle(
            name='CustomNormal',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceAfter=6
        ))
    
    def generate_payment_receipt(self, receipt_data, output_path=None):
        """Generate payment receipt PDF"""
        try:
            if output_path is None:
                output_path = f"receipt_{receipt_data['payment'].receipt_no}.pdf"
            
            doc = SimpleDocTemplate(output_path, pagesize=letter)
            story = []
            
            payment = receipt_data['payment']
            student = receipt_data['student']
            school = receipt_data['school']
            
            # Header
            story.append(Paragraph(school.name, self.styles['CustomTitle']))
            story.append(Paragraph("PAYMENT RECEIPT", self.styles['CustomHeading']))
            story.append(Spacer(1, 20))
            
            # Receipt details table
            receipt_data_table = [
                ['Receipt No:', payment.receipt_no, 'Date:', payment.payment_date.strftime('%d/%m/%Y')],
                ['Student Name:', student.name, 'Class:', student.class_info.get_display_name() if student.class_info else 'N/A'],
                ['Admission No:', student.admission_no, 'Roll No:', student.roll_number],
                ['Father\'s Name:', student.father_name, 'Phone:', student.phone]
            ]
            
            table = Table(receipt_data_table, colWidths=[1.5*inch, 2*inch, 1*inch, 1.5*inch])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, -1), colors.white),
                ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            story.append(table)
            story.append(Spacer(1, 20))
            
            # Payment details
            story.append(Paragraph("Payment Details", self.styles['CustomHeading']))
            
            payment_data = [
                ['Description', 'Amount'],
                ['Fee Payment', f"₹{payment.amount:,.2f}"],
                ['Payment Mode', payment.payment_mode.value.title()],
                ['Transaction ID', payment.transaction_id or 'N/A'],
                ['Collected By', payment.collector.name if payment.collector else 'N/A']
            ]
            
            payment_table = Table(payment_data, colWidths=[4*inch, 2*inch])
            payment_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#FF6F00')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('ALIGN', (1, 1), (1, -1), 'RIGHT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            story.append(payment_table)
            story.append(Spacer(1, 30))
            
            # QR Code
            qr_data = f"RECEIPT:{payment.receipt_no}:AMOUNT:{payment.amount}:DATE:{payment.payment_date}"
            qr_img = self.generate_qr_code(qr_data)
            if qr_img:
                story.append(Paragraph("Scan for verification:", self.styles['CustomNormal']))
                story.append(qr_img)
                story.append(Spacer(1, 20))
            
            # Footer
            story.append(Paragraph("Thank you for your payment!", self.styles['CustomNormal']))
            story.append(Paragraph(f"Generated on: {datetime.now().strftime('%d/%m/%Y %H:%M')}", 
                                 ParagraphStyle('Footer', parent=self.styles['Normal'], fontSize=8, alignment=TA_RIGHT)))
            
            doc.build(story)
            return True, output_path
            
        except Exception as e:
            return False, f"Error generating receipt: {str(e)}"
    
    def generate_student_id_card(self, student, output_path=None):
        """Generate student ID card PDF"""
        try:
            if output_path is None:
                output_path = f"id_card_{student.admission_no}.pdf"
            
            doc = SimpleDocTemplate(output_path, pagesize=(3.5*inch, 2.2*inch))
            story = []
            
            # School name
            story.append(Paragraph(student.school.name, 
                                 ParagraphStyle('SchoolName', parent=self.styles['Normal'], 
                                              fontSize=12, alignment=TA_CENTER, textColor=colors.HexColor('#FF6F00'))))
            story.append(Spacer(1, 10))
            
            # Student details table
            id_data = [
                [student.name, ''],
                [f"Class: {student.class_info.get_display_name() if student.class_info else 'N/A'}", ''],
                [f"Roll No: {student.roll_number}", ''],
                [f"Admission: {student.admission_no}", ''],
                [f"DOB: {student.date_of_birth.strftime('%d/%m/%Y') if student.date_of_birth else 'N/A'}", '']
            ]
            
            # Add photo placeholder if no photo
            if student.photo_url:
                # In a real implementation, you'd add the actual photo here
                id_data[0][1] = "PHOTO"
            else:
                id_data[0][1] = "NO PHOTO"
            
            id_table = Table(id_data, colWidths=[2*inch, 1*inch])
            id_table.setStyle(TableStyle([
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (0, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 8),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ]))
            
            story.append(id_table)
            
            doc.build(story)
            return True, output_path
            
        except Exception as e:
            return False, f"Error generating ID card: {str(e)}"
    
    def generate_fee_report(self, report_data, output_path=None):
        """Generate fee collection report PDF"""
        try:
            if output_path is None:
                output_path = f"fee_report_{datetime.now().strftime('%Y%m%d')}.pdf"
            
            doc = SimpleDocTemplate(output_path, pagesize=A4)
            story = []
            
            # Header
            story.append(Paragraph("Fee Collection Report", self.styles['CustomTitle']))
            story.append(Paragraph(f"Generated on: {datetime.now().strftime('%d/%m/%Y %H:%M')}", 
                                 self.styles['CustomNormal']))
            story.append(Spacer(1, 20))
            
            # Summary
            summary_data = [
                ['Total Collections', f"₹{report_data.get('total_collected', 0):,.2f}"],
                ['Total Transactions', str(report_data.get('total_transactions', 0))],
                ['Average Payment', f"₹{report_data.get('average_payment', 0):,.2f}"]
            ]
            
            summary_table = Table(summary_data, colWidths=[3*inch, 2*inch])
            summary_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, -1), colors.lightgrey),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
                ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 12),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            story.append(summary_table)
            story.append(Spacer(1, 30))
            
            # Payment mode breakdown
            if 'mode_breakdown' in report_data:
                story.append(Paragraph("Payment Mode Breakdown", self.styles['CustomHeading']))
                
                mode_data = [['Payment Mode', 'Amount']]
                for mode, amount in report_data['mode_breakdown'].items():
                    mode_data.append([mode.title(), f"₹{amount:,.2f}"])
                
                mode_table = Table(mode_data, colWidths=[3*inch, 2*inch])
                mode_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#FF6F00')),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('ALIGN', (1, 1), (1, -1), 'RIGHT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 0), (-1, -1), 10),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                
                story.append(mode_table)
            
            doc.build(story)
            return True, output_path
            
        except Exception as e:
            return False, f"Error generating report: {str(e)}"
    
    def generate_qr_code(self, data, size=1*inch):
        """Generate QR code image for PDF"""
        try:
            qr = qrcode.QRCode(version=1, box_size=10, border=5)
            qr.add_data(data)
            qr.make(fit=True)
            
            qr_img = qr.make_image(fill_color="black", back_color="white")
            
            # Save to BytesIO
            img_buffer = BytesIO()
            qr_img.save(img_buffer, format='PNG')
            img_buffer.seek(0)
            
            # Create reportlab Image
            img = Image(img_buffer, width=size, height=size)
            return img
            
        except Exception as e:
            print(f"Error generating QR code: {e}")
            return None